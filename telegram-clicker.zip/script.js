let count = 0;

window.onload = () => {
    const savedCount = localStorage.getItem("clickCount");
    if (savedCount !== null) {
        count = parseInt(savedCount);
        document.getElementById("count").innerText = count;
    }

    if (window.Telegram && Telegram.WebApp) {
        Telegram.WebApp.ready();
        Telegram.WebApp.setHeaderTitle("Кликер");
        Telegram.WebApp.expand();

        Telegram.WebApp.BackButton.show();
        Telegram.WebApp.BackButton.onClick(() => {
            Telegram.WebApp.close();
        });
    }

    const { init } = window['@tma.js/sdk'];
    try {
        const user = init();
        if (user && user.username) {
            document.getElementById("username").innerText = user.username;
        }
    } catch (e) {
        console.error("Ошибка инициализации TMA SDK", e);
    }
};

function clickButton() {
    count++;
    document.getElementById("count").innerText = count;
    localStorage.setItem("clickCount", count);
    if (navigator.vibrate) {
        navigator.vibrate(20);
    }
}